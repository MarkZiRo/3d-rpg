using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;

public class MonsterController : Creature
{
    Stat stat;

	[SerializeField]
	float scanRange = 5;

	[SerializeField]
	float attackRange = 1.5f;

	[SerializeField]
	Animator anim;

	private void OnEnable()
	{
		
	}

	protected override void Init()
	{
		WorldObjectType = Define.WorldObject.Monster;

		stat = GetComponent<Stat>();
		anim = GetComponent<Animator>();


		if (gameObject.GetComponentInChildren<UI_HPBar>() == null)
		{
			GameObject go = GameManagers.Resource.Instantiate($"UI_HP");
			go.transform.SetParent(transform);
			Canvas canvas = go.GetOrAddComponent<Canvas>();
			canvas.renderMode = RenderMode.WorldSpace;
			canvas.worldCamera = Camera.main;
		}
	}

	protected override void Update()
	{
		base.Update();
	}

	protected override void UpdateIdle()
	{
		anim.SetFloat("speed", 0);

		GameObject player = GameObject.FindGameObjectWithTag("Player");
		if (player == null)
			return;

		float distance = (player.transform.position - transform.position).magnitude;

		if(distance <= scanRange)
		{
			Debug.Log("?");
			target = player;
			_state = Define.State.Moving;
			return;
		}
		else
		{
			_state = Define.State.Idle;
		}
	}

	protected override void UpdateMoving()
	{
		// ���Ͱ� �� �����Ÿ� ���� ������ ���ݻ���.
		if (target != null)
		{
			DestPosition = target.transform.position;
			float distance = (DestPosition - transform.position).magnitude;

			//    Debug.Log(distance);
			if (distance <= attackRange && target)
			{
				NavMeshAgent navMesh = gameObject.GetOrAddComponent<NavMeshAgent>();
				navMesh.SetDestination(transform.position);
				_state = Define.State.Attack;
				return;
			}
		}

		Vector3 dir = DestPosition - transform.position;
	//	Debug.Log("MOVEING" + dir.magnitude);
		if (dir.magnitude < 0.1f)
		{
			_state = Define.State.Idle;
		}

		else if (dir.magnitude > 7f)
		{
			_state = Define.State.Idle;
		}

		else
		{
			NavMeshAgent navMesh = gameObject.GetOrAddComponent<NavMeshAgent>();

			navMesh.SetDestination(DestPosition);
			navMesh.speed = stat.MoveSpeed;

			transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 10 * Time.deltaTime);
		}

	
		anim.SetFloat("speed", stat.MoveSpeed);
	}

	protected override void UpdateAttack()
	{
		anim.SetBool("attack", true);

		if (target != null)
		{
			Vector3 dir = target.transform.position - transform.position;
			Quaternion quat = Quaternion.LookRotation(dir);
			transform.rotation = Quaternion.Lerp(transform.rotation, quat, 20 * Time.deltaTime);
		}
	}

	protected override void UpdateDie()
	{
		base.UpdateDie();
	}

	void OnHitEvent()
	{
		anim.SetBool("attack", false);
		//Debug.Log(target);

		if(target != null)
		{
			if (target.activeSelf)
			{
				Stat playerStat = target.GetComponent<Stat>();
				playerStat.OnAttacked(stat);

				if (playerStat.Hp > 0)
				{
					float distance = (target.transform.position - transform.position).magnitude;
					if (distance <= attackRange)
					{
						_state = Define.State.Attack;
					}
					else
						_state = Define.State.Moving;
				}
			}
			else
			{
				_state = Define.State.Idle;
			}
		}
		else
		{
			_state = Define.State.Idle;
		}
	}
}
