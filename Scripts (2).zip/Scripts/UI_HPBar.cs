using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_HPBar : MonoBehaviour
{

	Stat stat;
    GameObject levelUpText;

	void Start()
    {
        stat = transform.parent.GetComponent<Stat>();
        levelUpText = transform.GetChild(1).gameObject;

		float ratio = stat.Hp / (float)stat.MaxHp;
		SetHpRatio(ratio);
	}

    void Update()
    {
        Transform parent = transform.parent;

        transform.position = parent.position + Vector3.up * (parent.GetComponent<Collider>().bounds.size.y);
        transform.LookAt(Camera.main.transform.position);
        transform.rotation = Camera.main.transform.rotation;
    
        float ratio = stat.Hp / (float)stat.MaxHp;

        SetHpRatio(ratio);
    }

    public void SetHpRatio(float ratio)
    {
        Slider slider = transform.GetChild(0).GetComponent<Slider>();
        slider.value = ratio;
    }

    public void ShowLevelUp()
    {
		levelUpText.SetActive(true);
		StartCoroutine("ShowLevelUpCo");
    }

    IEnumerator ShowLevelUpCo()
    {
        yield return new WaitForSeconds(3f);
        levelUpText.SetActive(false);
    }
}
