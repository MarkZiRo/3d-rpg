using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Shop_Npc : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ChoiceItem1()
    {
        if(Input.GetMouseButton(0)) 
        {
            if(!EventSystem.current.IsPointerOverGameObject())
            {
                Debug.Log("!!");   
            }
        }
    }
}
