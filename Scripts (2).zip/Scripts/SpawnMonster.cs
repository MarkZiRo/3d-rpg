using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;

public class SpawnMonster : MonoBehaviour
{
    [SerializeField]
    int monsterCount = 0;

    [SerializeField]
    int reserveCount = 0;

    [SerializeField]
    int keepMonsterCount = 0;

    [SerializeField]
    Vector3 spawnPos = new Vector3(70,0,12);

    [SerializeField]
    float spawnRadius = 13.0f;

    [SerializeField]
    float spawnTime = 8.0f;


    public void AddMonsterCount(int value)
    {
        monsterCount += value;
    }

    public void SetKeepMonsterCount(int count)
    {
        keepMonsterCount = count;
    }

    void Start()
    {
		GameManagers.Spawn.spawnEvent -= AddMonsterCount;
        GameManagers.Spawn.spawnEvent += AddMonsterCount;
    }

    // Update is called once per frame
    void Update()
    {
        while(monsterCount + reserveCount < keepMonsterCount)
        {
           
            StartCoroutine("ReserveSpawn");
        }
    }

    IEnumerator ReserveSpawn()
    {
        reserveCount++;
        yield return new WaitForSeconds(Random.Range(1, spawnTime));
   //     Debug.Log(reserveCount);
		GameObject obj = GameManagers.Spawn.Spawn(Define.WorldObject.Monster, "Knight");
        obj.transform.position = spawnPos;
        NavMeshAgent agent = obj.GetOrAddComponent<NavMeshAgent>();
        Stat stat = obj.GetOrAddComponent<Stat>();
        stat.Hp = 100;

        Vector3 randPos;

        while (true)
        {
            Vector3 randDir = Random.insideUnitSphere * Random.Range(0, spawnRadius);
            randDir.y = 0;
            randPos = spawnPos + randDir;

            NavMeshPath path = new NavMeshPath();
            if (agent.CalculatePath(randPos, path))
                break;
        }

      obj.transform.position = randPos;
	  reserveCount--;
	}
}
