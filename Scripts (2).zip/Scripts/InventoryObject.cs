using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEditor;
using UnityEngine;
using UnityEngine.VFX;

[CreateAssetMenu(fileName = "New Inventory", menuName = "InventorySystem/Inventory")]
public class InventoryObject : ScriptableObject
{
    public string savePath;
    public ItemDatabaseObject database;
    public Inventory Container;
    public InventorySlot[] GetSlots { get { return Container.Slots; } }

//	private void OnEnable()
//	{
//#if UNITY_EDITOR
//        database = (ItemDatabaseObject)AssetDatabase.LoadAssetAtPath("Assets/Resources/Data/Database.asset", typeof(ItemDatabaseObject));
// #else
//        database = Resources.Load<ItemDatabaseObject>("Data/Database");
//#endif
//    }

	public bool AddItem(Item _item, int _amount)
    {
        if (EmptySlotCount <= 0)
            return false;

        InventorySlot slot = FindItemOnInventory(_item);
        Debug.Log(database);
     //   Debug.Log(database.ItemsObjects[0]);
        Debug.Log(database.ItemsObjects[_item.Id]);
        if (!database.ItemsObjects[_item.Id].stackable || slot == null )
        {
            SetEmptySlot(_item, _amount);
            return true;
        }

        slot.AddAmount(_amount);
        return true;
	}

    public int EmptySlotCount
    {
        get
        {
            int counter = 0;
            for(int i=0; i< GetSlots.Length; i++) 
            {
                if (GetSlots[i].item.Id <= -1)
                    counter++;
            }
            return counter;
        }
    }

    public InventorySlot FindItemOnInventory(Item _item)
    {
        for(int i=0; i< GetSlots.Length; i++)
        {
            if (GetSlots[i].item.Id == _item.Id)
            {
                return GetSlots[i];
            }
        }

        return null;
    }

    public InventorySlot SetEmptySlot(Item _item , int _amount)
    {
        for(int i=0; i< GetSlots.Length; ++i)
        {
            if (GetSlots[i].item.Id <= -1)
            {
                GetSlots[i].UpdataSlot( _item, _amount);
                return GetSlots[i];
            }
        }

        return null;
    }

    public void SwapItems(InventorySlot item1, InventorySlot item2)
    {
        if(item2.CanPlaceInSlot(item1.itemObject) && item1.CanPlaceInSlot(item2.itemObject))
        {
            InventorySlot temp = new InventorySlot(item2.item, item2.amount);
            item2.UpdataSlot(item1.item, item1.amount);
            item1.UpdataSlot(temp.item, temp.amount);
        }
	
	}

    public void RemoveItem(Item _item)
    {
        for(int i=0; i<GetSlots.Length; ++i) 
        {
            if (GetSlots[i].item == _item)
                GetSlots[i].UpdataSlot( null, 0);
        }
    }


    [ContextMenu("Save")]
    public void Save()
    {
        //string savaData = JsonUtility.ToJson(this, true);
        //BinaryFormatter bf = new BinaryFormatter();
        //FileStream file = File.Create(string.Concat(Application.persistentDataPath, savePath));
        //bf.Serialize(file, savaData);
        //file.Close();

        IFormatter formatter = new BinaryFormatter();
        Stream stream = new FileStream(string.Concat(Application.persistentDataPath, savePath), FileMode.Create, FileAccess.Write);
        formatter.Serialize(stream, Container);
        stream.Close();
    }

    [ContextMenu("Load")]
    public void Load()
    {
        if(File.Exists(string.Concat(Application.persistentDataPath, savePath)))
        {
            //BinaryFormatter bf = new BinaryFormatter();
            //FileStream file = File.Open(string.Concat(Application.persistentDataPath, savePath), FileMode.Open);
            //JsonUtility.FromJsonOverwrite(bf.Deserialize(file).ToString(), this);
            //file.Close();

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream(string.Concat(Application.persistentDataPath, savePath), FileMode.Open, FileAccess.Read);
            Inventory newConatiner = (Inventory)formatter.Deserialize(stream);
            for (int i = 0; i < GetSlots.Length; i++)
            {
                GetSlots[i].UpdataSlot(newConatiner.Slots[i].item, newConatiner.Slots[i].amount);
            }
            stream.Close();
        }
    }

    [ContextMenu("Clear")]
    public void Clear()
    {
        Container.Clear();
    }

	public void OnBeforeSerialize()
	{

	}
}

[System.Serializable]
public class Inventory
{
	public InventorySlot[] Slots = new InventorySlot[24];
    public void Clear()
    {
        for(int i=0; i< Slots.Length; i++)
        {
			Slots[i].RemoveItem();
        }
    }
}

public delegate void SlotUpdate(InventorySlot _slot);

[System.Serializable]
public class InventorySlot
{
    public ItemType[] AllowedItems = new ItemType[0];
    [System.NonSerialized]
    public UserInterface parent;
	
    [System.NonSerialized]
	public GameObject slotDisplay;
    
    [System.NonSerialized]
    public SlotUpdate OnAfterUpdate;
	[System.NonSerialized]
	public SlotUpdate OnBeforeUpdate;

	public Item item;
    public int amount;

    public ItemObject itemObject
    {
        get
        {
            if(item.Id >=0)
            {
                int a = 5;
                return parent.inventory.database.ItemsObjects[item.Id];
            }

            return null;
        }
    }

    public InventorySlot()
    {
        UpdataSlot(new Item(), 0);
	}

    public InventorySlot(Item _item, int _amount)
    {
		UpdataSlot( _item, amount);
	}

	public void UpdataSlot(Item _item, int _amount)
	{
        if (OnBeforeUpdate != null)
            OnBeforeUpdate.Invoke(this);

		item = _item;
		amount = _amount;

        if(OnAfterUpdate != null)
            OnAfterUpdate.Invoke(this);
	}

    public void RemoveItem()
    {
        item = new Item();
        amount = 0;
    }
	public void AddAmount(int value)
    {
		UpdataSlot(item, amount += value);
	}

    public bool CanPlaceInSlot(ItemObject _itemObject)
    {
        if (AllowedItems.Length <= 0 || _itemObject == null || _itemObject.data.Id <0)
            return true;

        for(int i=0; i<AllowedItems.Length; i++) 
        {
            if (_itemObject.type == AllowedItems[i])
                return true;
        }

        return false;
    }
}
