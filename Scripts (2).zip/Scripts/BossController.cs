using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;

public class BossController : Creature
{
	Stat stat;

	[SerializeField]
	float scanRange = 12f;

	[SerializeField]
	float attackRange = 6f;

	[SerializeField]
	Animator anim;

	public float fireSpeed = 6f;

	private float spawnRate = 3f;
	private float timeAfterSpawn =2f;

	public Transform FireStart;
	private void OnEnable()
	{

	}

	protected override void Init()
	{
		timeAfterSpawn = 2f;
		WorldObjectType = Define.WorldObject.Monster;

		stat = GetComponent<Stat>();
		anim = GetComponent<Animator>();


		if (gameObject.GetComponentInChildren<UI_HPBar>() == null)
		{
			GameObject go = GameManagers.Resource.Instantiate($"UI_HP");
			go.transform.SetParent(transform);
			Canvas canvas = go.GetOrAddComponent<Canvas>();
			canvas.renderMode = RenderMode.WorldSpace;
			canvas.worldCamera = Camera.main;
		}
	}

	protected override void Update()
	{
		base.Update();
	}

	protected override void UpdateIdle()
	{
		anim.SetFloat("speed", 0);

		GameObject player = GameObject.FindGameObjectWithTag("Player");
		if (player == null)
			return;

		float distance = (player.transform.position - transform.position).magnitude;

		//		Debug.Log(distance);

		if (distance <= scanRange)
		{
			target = player;
			_state = Define.State.Moving;
			return;
		}
	}

	protected override void UpdateMoving()
	{
		// ���Ͱ� �� �����Ÿ� ���� ������ ���ݻ���.
		if (target != null)
		{
			DestPosition = target.transform.position;
			float distance = (DestPosition - transform.position).magnitude;

			//    Debug.Log(distance);
			if (distance <= attackRange && target)
			{
				NavMeshAgent navMesh = gameObject.GetOrAddComponent<NavMeshAgent>();
				navMesh.SetDestination(transform.position);
				_state = Define.State.Attack;
				return;
			}
		}

		Vector3 dir = DestPosition - transform.position;
		if (dir.magnitude < 0.1f)
		{
			_state = Define.State.Idle;
		}

		else if(dir.magnitude > 10f)
		{
			_state = Define.State.Skill;
		}

		else
		{
			NavMeshAgent navMesh = gameObject.GetOrAddComponent<NavMeshAgent>();

			navMesh.SetDestination(DestPosition);
			navMesh.speed = stat.MoveSpeed;

			transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 10 * Time.deltaTime);
		}


		anim.SetFloat("speed", stat.MoveSpeed);
	}

	protected override void UpdateAttack()
	{
		anim.SetBool("attack", true);

		if (target != null)
		{
			Vector3 dir = target.transform.position - transform.position;
			Quaternion quat = Quaternion.LookRotation(dir);
			transform.rotation = Quaternion.Lerp(transform.rotation, quat, 20 * Time.deltaTime);
		}
	}

	protected override void UpdateDie()
	{
		base.UpdateDie();
	}

	void OnHitEvent()
	{
		anim.SetBool("attack", false);
		//Debug.Log(target);

		if (target != null)
		{
			if (target.activeSelf)
			{
				Stat playerStat = target.GetComponent<Stat>();
				playerStat.OnAttacked(stat);

				if (playerStat.Hp > 0)
				{
					float distance = (target.transform.position - transform.position).magnitude;
					if (distance <= attackRange)
					{
						_state = Define.State.Attack;
					}
					else
						_state = Define.State.Moving;
				}
			}
			else
			{
				_state = Define.State.Idle;
			}
		}
		else
		{
			_state = Define.State.Idle;
		}
	}

	protected override void UpdateSkill()
	{
		anim.SetBool("skill", true);
		if (target != null)
		{
			if(target.activeSelf)
			{ 

				timeAfterSpawn += Time.deltaTime;

				if(timeAfterSpawn >= spawnRate)
				{
					timeAfterSpawn = 0f;

					GameObject go = GameManagers.Resource.Instantiate("Fire");
					go.transform.position = FireStart.transform.position;
					go.transform.LookAt(target.transform.position);

					anim.SetBool("skill", false);
				}

			}
		}

		DestPosition = target.transform.position;
		Vector3 dir = DestPosition - transform.position;
		Debug.Log(dir.magnitude);
		if (dir.magnitude < 0.1f)
		{
			_state = Define.State.Idle;
		}

		else if (dir.magnitude > 10f)
		{
			_state = Define.State.Skill;
		}

		else
		{
			anim.SetBool("skill", false);
			_state = Define.State.Attack;
		}
	}
}
