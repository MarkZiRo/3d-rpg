using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class GameScene : MonoBehaviour
{
	static GameScene Instance;

	GameObject player;
	// Start is called before the first frame update
	private void Awake()
	{
		//	GameManagers.Spawn.Spawn(Define.WorldObject.Player, "Player");
		Instance = this;
	}

	void Start()
	{
		player = GameManagers.Spawn.Spawn(Define.WorldObject.Player, "Player");
		GameManagers.Spawn.Spawn(Define.WorldObject.Monster, "Knight");

		Camera.main.gameObject.GetOrAddComponent<CameraController>().SetPlayer(player);
		GameManagers.GetInstance().SetPlayer(player);
		//List<GameObject> list = new List<GameObject>();

		//for (int i = 0; i < 5; i++)
		//{
		//	list.Add(GameManagers.Resource.Instantiate("Player"));
		//}

		//foreach (GameObject obj in list)
		//{
		//	GameManagers.Resource.Destroy(obj);
		//}

		GameObject go = new GameObject { name = "SpawningPool" };
		SpawnMonster pool = go.GetOrAddComponent<SpawnMonster>();
		pool.SetKeepMonsterCount(2);
	}

}
