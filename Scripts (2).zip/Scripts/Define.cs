using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Define 
{
	public enum WorldObject
	{
		UnKnown,
		Player,
		Monster,
		Boss,
		Npc
	}

	public enum Layer
	{
		Ground = 6,
		Wall = 7,
		Monster =8,
		Boss = 9,
		Npc = 10
	}

	public enum State
    {
        Die,
        Moving,
        Idle,
        Attack,
		Skill
	}
}
