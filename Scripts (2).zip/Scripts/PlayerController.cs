using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.EventSystems;

public class PlayerController : Creature
{
    PlayerStat _stat;

    Animator anim;

    Texture2D AttackIcon;
    Texture2D BasicIcon;

    public bool isDrag;
	public bool isNpc;

	public InventoryObject inventory;
    public InventoryObject equipment;

    public GameObject inventory_UI;
    public GameObject equipment_UI;

//	public MouseItem mouseItem = new MouseItem();


	enum CursorType
    {
        None,
        Basic,
        Attack,
    }

    CursorType cursorType = CursorType.None;

	public enum MouseEvent
	{
        None,
		Press,
		PointDown,
		PointUp,
		Click
	}

    MouseEvent _mouse = MouseEvent.None;

	protected override void Init()
	{
		inventory.Container.Clear();
		equipment.Container.Clear();

		isDrag = true;
		WorldObjectType = Define.WorldObject.Player;

		AttackIcon = GameManagers.Resource.Load<Texture2D>("Cursor/Attack");
		BasicIcon = GameManagers.Resource.Load<Texture2D>("Cursor/Basic");

		_stat = gameObject.GetComponent<PlayerStat>();

		anim = GetComponent<Animator>();

        Dictionary<int, Data.Stat> dict = GameManagers.Data.StatDictionary;

        if (gameObject.GetComponentInChildren<UI_HPBar>() == null)
        {
            GameObject go = GameManagers.Resource.Instantiate($"UI_HP");
            go.transform.SetParent(transform);
            Canvas canvas = go.GetOrAddComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = Camera.main;
        }
	}

    int _mask = (1 << (int)Define.Layer.Ground) | (1 << (int)Define.Layer.Monster );
    int _npcmask = 1 << (int)Define.Layer.Npc;


	bool _pressed = false;
    float _pressTime = 0;

    bool stopSkill = false;

	protected override void Update()
    {
		UpdateMouseCursor();

		if (Input.GetMouseButton(0))
        {
            if (_state == Define.State.Die || EventSystem.current.IsPointerOverGameObject() == true || isDrag ==false)
                return;

			stopSkill = false;

			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            RaycastHit hit;

            if(Physics.Raycast(ray, out hit, 100.0f, _mask))
            {
                DestPosition = hit.point;
                _state = Define.State.Moving;
			}

			if (Physics.Raycast(ray, out hit, 100.0f, _npcmask))
			{
				DestPosition = hit.point;

				Vector3 dir = DestPosition - transform.position;
				dir.y = 0;
				if (dir.magnitude < 0.1f)
				{
                    Debug.Log("!!");
				}

			}

			// ���콺�κ�
			if (!_pressed)
            {
                _pressTime = Time.time;
            }

		
			_pressed = true;
        }
        else
        {
            if(_pressed)
            {
                //if(Time.time < _pressTime +0.2f)
                //{
                //    _mouse = MouseEvent.Click;
                //}

                _mouse = MouseEvent.PointUp;
            }

            _pressed = false;
            _pressTime = 0;
        }

        base.Update();

        switch(_mouse)
        {
            case MouseEvent.PointUp:
                stopSkill = true;
                break;
		}

        if (Input.GetKeyDown(KeyCode.I))
        {
            if (inventory_UI.activeSelf == false)
                inventory_UI.SetActive(true);

            else
                inventory_UI.SetActive(false);

		}

        if (Input.GetKeyDown(KeyCode.P))
        {
            if (equipment_UI.activeSelf == false)
                equipment_UI.SetActive(true);

            else
                equipment_UI.SetActive(false);

        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            equipment.Save();
			inventory.Save();
        }
        if(Input.GetKeyDown(KeyCode.KeypadEnter))
        {
			equipment.Load();
			inventory.Load();
        }
    }

	protected override void UpdateAttack()
    {
        anim.SetBool("attack", true);

        if(target != null)
        {
            Vector3 dir = target.transform.position - transform.position;
            Quaternion quat = Quaternion.LookRotation(dir);
            transform.rotation = Quaternion.Lerp(transform.rotation, quat, 20 * Time.deltaTime);
        }
    }

    void OnHitEvent()
    {
        anim.SetBool("attack", false);

        if(target != null) 
        {
            Stat targetStat = target.GetComponent<Stat>();
            targetStat.OnAttacked(_stat);
            SoundManager.instance.PlaySFX("Attack");
        }


        if (stopSkill)
            _state = Define.State.Idle;

        else
            _state = Define.State.Attack;
    }

    void UpdateMouseCursor()
    {
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

		RaycastHit hit;

		if (Physics.Raycast(ray, out hit, 100.0f, _mask))
		{
			if (hit.collider.gameObject.layer == (int)Define.Layer.Monster)
			{
                if (cursorType == CursorType.Attack)
                    return;

                Cursor.SetCursor(AttackIcon, new Vector2(AttackIcon.width/5,0), CursorMode.Auto);
                cursorType = CursorType.Attack;
                target = hit.collider.gameObject;
			}
			else
			{
				if (cursorType == CursorType.Basic)
					return;

				Cursor.SetCursor(BasicIcon, new Vector2(BasicIcon.width / 3, 0), CursorMode.Auto);
				cursorType = CursorType.Basic;
                target = null;
			}
		}
	}

	protected override void UpdateDie()
    {

    }

    protected override void UpdateMoving()
    {
       
        // ���Ͱ� �� �����Ÿ� ���� ������ ���ݻ���.
        if(target != null)
        {
            float distance = (DestPosition - transform.position).magnitude;

        //    Debug.Log(distance);
            if(distance <=1.2f && target )
            {
                _state = Define.State.Attack;
                return;
            }
		}


		Vector3 dir = DestPosition - transform.position;
        dir.y = 0;
		if (dir.magnitude < 0.1f)
		{
            _state = Define.State.Idle;
		}
		else
		{

            if (Physics.Raycast(transform.position +  Vector3.up * 0.5f, dir, 1.0f, LayerMask.GetMask("Wall") | LayerMask.GetMask("Npc")))
            {
                _state = Define.State.Idle;
                return;

            }

			float moveDist = Mathf.Clamp(_stat.MoveSpeed * Time.deltaTime, 0, dir.magnitude);
            transform.position += dir.normalized * moveDist;
			transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 10 * Time.deltaTime);
		}

        //    anim.SetFloat()
        anim.SetFloat("speed", _stat.MoveSpeed);
        
	}

	protected override void UpdateIdle()
    {
		anim.SetFloat("speed", 0);
	}

	public void OnTriggerEnter(Collider other)
	{
		var item = other.GetComponent<GroundItem>();
        if(item)
        {
            Item _item = new Item(item.item);
            if (inventory.AddItem(new Item(item.item), 1))
            {
                Destroy(other.gameObject);
            }
		}
	}

	private void OnApplicationQuit()
	{
        inventory.Container.Clear();
        equipment.Container.Clear();
	}
}
