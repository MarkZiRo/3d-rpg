using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Billboard : MonoBehaviour
{
    void Start()
    {
        
    }

    // Update is called once per frame
    void LateUpdate()
    {
		// if(Camera == null)
		transform.LookAt(Camera.main.transform);
		transform.rotation = Camera.main.transform.rotation;
	}
}
