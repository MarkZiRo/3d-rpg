using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class SpawnManager
{

	GameObject player;
	HashSet<GameObject> monsters = new HashSet<GameObject>();

	public Action<int> spawnEvent;


	public GameObject Spawn(Define.WorldObject type, string path, Transform parent = null)
	{
		GameObject go = GameManagers.Resource.Instantiate(path, parent);

		switch (type)
		{
			case Define.WorldObject.Monster:
				monsters.Add(go);
				go.transform.position = new Vector3(70, 0, 12);
				if (spawnEvent != null)
					spawnEvent.Invoke(1);
				break;

			case Define.WorldObject.Player:
				player = go;
				player.transform.position = new Vector3(15f, 0f, 10f);
				break;
		}

		return go;
	}

	public Define.WorldObject GetWorldObjectType(GameObject go)
	{
		Creature creature = go.GetComponent<Creature>();

		if (creature == null)
			return Define.WorldObject.UnKnown;

		return creature.WorldObjectType;
	}



	public void Despawn(GameObject go)
	{
		Define.WorldObject type = GetWorldObjectType(go);

		switch (type)
		{
			case Define.WorldObject.Monster:
				{
					if (monsters.Contains(go))
						monsters.Remove(go);
					if(spawnEvent != null) 
						spawnEvent.Invoke(-1);
				}
				break;

			case Define.WorldObject.Player:
				{
					if (player == go)
						player = null;
				}
				break;
		}

		GameManagers.Resource.Destroy(go);
	}
}
