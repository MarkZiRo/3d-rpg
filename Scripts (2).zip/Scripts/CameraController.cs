using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class CameraController : MonoBehaviour
{
    [SerializeField]
    Vector3 Delta;

    [SerializeField]
    GameObject Player;
    void Start()
    {
        
    }

    // Update is called once per frame
    void LateUpdate()
    {

        if(Player == null || !Player.activeSelf || Player.GetComponent<PlayerController>().isNpc == true)
        {
         //   Debug.Log("!!");
            return;
        }

        RaycastHit hit;

        if (Physics.Raycast(Player.transform.position, Delta, out hit, Delta.magnitude, LayerMask.GetMask("Wall")))
        {
            float dist = (hit.point - Player.transform.position).magnitude;
            transform.position = Player.transform.position + Delta.normalized * dist + new Vector3(0.0f, 0.7f, 0.0f);
        }

        else
        {
            transform.position = Player.transform.position + Delta;
            transform.LookAt(Player.transform);
        }
    }

    public void SetPlayer(GameObject player)
    {
        Player = player;
    }
}
