using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerStat : Stat
{
	[SerializeField]
	protected int _currentexp;

	[SerializeField]
	protected int _gold;

	public GameObject charStat;

	public TextMeshProUGUI Level_Text;
	public TextMeshProUGUI Hp_Text;
	public TextMeshProUGUI Attack_Text;
	public TextMeshProUGUI Exp_Text;


	public int CurrExp
	{ 
		get { return _currentexp; } 
		set
		{
			_currentexp = value;

			int level = Level;
			while(true)
			{
				Data.Stat stat;
				if (GameManagers.Data.StatDictionary.TryGetValue(level + 1, out stat) == false)
					break;

				if (_currentexp < stat.totalExp)
					break;

				UI_HPBar hpBar = transform.GetChild(2).GetComponent<UI_HPBar>();
				hpBar.ShowLevelUp();
				level++;
			}

			if(level != Level)
			{
				Debug.Log("level");
				Level = level;
				SetStat(Level);
			}
		} 
	}
	public int Gold { get { return _gold; } set { _gold = value; } }

	private void Start()
	{
		_level = 1;

		_exp = 0;
		_moveSpeed = 5.0f;
		_currentexp = 0;
	    _gold = 0;

		SetStat(_level);
	}

	public void SetStat(int level)
	{
		Dictionary<int, Data.Stat> dict = GameManagers.Data.StatDictionary;
		Data.Stat stat = dict[level];

		_hp = stat.maxHp;
		_maxHp = stat.maxHp;
		_attack = stat.attack;
		Level_Text.text = _level.ToString();
		Hp_Text.text = _hp.ToString();
		Attack_Text.text = _attack.ToString();
		Exp_Text.text = _exp.ToString();

	}


	protected override void OnDead(Stat attacker)
	{
	//	base.OnDead();
	}

}
