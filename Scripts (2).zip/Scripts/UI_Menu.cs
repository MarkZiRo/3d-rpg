using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UI_Menu : MonoBehaviour
{

    public string loadScene;

    public GameObject SoundMenu;
    public GameObject MainMenu;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void StartGame()
    {
        SceneManager.LoadScene(loadScene);
    }


    public void QuitGame()
    {
        Application.Quit();
    }

    public void OpenOption()
    {
        SoundMenu.SetActive(true);
        MainMenu.SetActive(false);
    }

    public void CloseOption()
    {
		SoundMenu.SetActive(false);
		MainMenu.SetActive(true);
	}
}
