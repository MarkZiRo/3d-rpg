using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.VFX;

public class GameManagers : MonoBehaviour
{
    static GameManagers Instance;
    public static GameManagers GetInstance() { Init(); return Instance; }

    PoolManager _Pool = new PoolManager();
    SpawnManager _Spawn = new SpawnManager();
    ResourceManager _Resource = new ResourceManager();
    DataManager _Data = new DataManager();

    public GameObject Player;

    public static PoolManager Pool {  get { return Instance._Pool; } }

    public static SpawnManager Spawn {  get {  return Instance._Spawn; } }

    public static DataManager Data {  get { return Instance._Data; } }

	public static ResourceManager Resource {  get { return Instance._Resource; } }

    void Awake()
    {
        Init();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    static void Init()
    {
        if(Instance == null)
        {
            GameObject go = GameObject.Find("GameManagers");
            if(go == null)
            {
                go = new GameObject { name = "GameManagers" };
                go.AddComponent<GameManagers>();
            }

            DontDestroyOnLoad(go);
            Instance = go.GetComponent<GameManagers>();
        }

        Instance._Data.Init();
        Instance._Pool.Init();
	}

    public static void Clear()
    {
        Pool.Clear();
    }

	public void SetPlayer(GameObject player)
	{
		Player = player;
	}
}
