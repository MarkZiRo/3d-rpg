using Data;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    GameObject player;
	Stat stat;

	void Start()
    {
		player = GameManagers.GetInstance().Player;
		stat = player.GetComponent<Stat>();

	}

    // Update is called once per frame
    void Update()
    {
		
		Slider slider = transform.GetChild(0).GetComponent<Slider>();
      
     
	    float ratio = stat.Hp / (float)stat.MaxHp;
		SetHpRatio(ratio);
	}

	public void SetHpRatio(float ratio)
	{
		Slider slider = transform.GetChild(0).GetComponent<Slider>();
		slider.value = ratio;
	}
}
