using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadingScene : MonoBehaviour
{
  
    public string sceneName;

    [SerializeField]
    Image progressBar;
    void Start()
    {
        StartCoroutine(LoadAsyncScene());
    }

    IEnumerator LoadAsyncScene()
    {

        yield return null;

        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneName);
        operation.allowSceneActivation = false;

        float timer = 0.0f;


		while (!operation.isDone)
		{
			yield return null;

			timer += Time.deltaTime;

			if (operation.progress < 0.9f)
			{
				progressBar.fillAmount = Mathf.Lerp(progressBar.fillAmount, operation.progress, timer);

				if (progressBar.fillAmount >= operation.progress)
				{
					timer = 0f;
				}
			}

			else
			{
				progressBar.fillAmount = Mathf.Lerp(progressBar.fillAmount, 1f, timer);

				if (progressBar.fillAmount == 1.0f)
				{
					operation.allowSceneActivation = true;
					yield break;

				}
			}
		}
	}
}

