using Data;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stat : MonoBehaviour
{
	[SerializeField]
	protected int _level;

	[SerializeField]
	protected int _hp;

	[SerializeField]
	protected int _maxHp;

	[SerializeField]
	protected int _attack;

	[SerializeField]
	protected float _moveSpeed;

	[SerializeField]
	protected int _exp;

	public int Level { get { return _level; } set { _level = value; } }
	public int Hp { get { return _hp; } set { _hp = value; } }
	public int MaxHp { get { return _maxHp; } set { _maxHp = value; } }

	public int Attack { get { return _attack; } set { _attack = value; } }
	public float MoveSpeed { get { return _moveSpeed; } set { _moveSpeed = value; } }

	public int Exp { get { return _exp; } set { _exp = value; } }

	Animator anim;

	public GameObject[] DropItem;

	private void Start()
	{
		_level = 1;
		_hp = 100;
		_maxHp = 100;
		_attack = 3;
		_moveSpeed = 3.3f;
		//	creature = GetComponent<Creature>();
		anim = GetComponent<Animator>();
	}

	public virtual void OnAttacked(Stat attacker)
	{

		int damage = attacker.Attack;
	    Hp -= damage;

		if (Hp <= 0)
		{
			Hp = 0;
			OnDead(attacker);
		}
	}

	public virtual void OnAttacked(int attacker)
	{

		int damage = attacker;
		Hp -= damage;

		if (Hp <= 0)
		{
			Hp = 0;
		//	OnDead(attacker);
		}
	}

	protected virtual void OnDead(Stat attacker)
	{
		PlayerStat playerStat = attacker as PlayerStat;
		if(playerStat != null) 
		{
			playerStat.CurrExp += 15;
		}

		//StartCoroutine(DieAnimation());

	
		int random = Random.Range(0, 7);

		GameObject go = Instantiate(DropItem[random], transform.position + new Vector3(0,1,0), Quaternion.identity);

	
		GameManagers.Spawn.Despawn(gameObject);
	}


	IEnumerator DieAnimation()
	{
		anim.SetBool("die", true);
		yield return new WaitForSeconds(4f);
	}

}
