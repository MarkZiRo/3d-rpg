using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;


public class ResourceManager
{

  //  Dictionary<string, UnityEngine.Object> resources = new Dictionary<string, UnityEngine.Object>();

	public T Load<T>(string path) where T : Object
    {
        if(typeof(T) == typeof(GameObject))
        {
            string name = path;
            int index = name.LastIndexOf('/');
            if(index >=0)
                name = name.Substring(index+1);

            GameObject go = GameManagers.Pool.GetOriginal(name);

            if (go != null)
                return go as T;

        }

        return Resources.Load<T>(path);
    }

    public GameObject Instantiate(string path, Transform parent = null)
    {
        GameObject original = Load<GameObject>($"Prefabs/{path}");
        if(original == null)
        {
            return null;
        }

        // Ǯ��.

        if (original.GetComponent<Poolable>() != null)
            return GameManagers.Pool.Pop(original, parent).gameObject;

        GameObject go = Object.Instantiate(original, parent);
        go.name = original.name;

        return go;
    }

	public void Destroy(GameObject go)
	{
        if (go == null)
            return;

        // Ǯ���� �ʿ��ϴٸ� Ǯ�� �Ŵ������� ��Ź.

        Poolable poolable = go.GetComponent<Poolable>();
        if(poolable != null)
        {
            GameManagers.Pool.Push(poolable);
            return;
        }


        Destroy(go);
	}
}
