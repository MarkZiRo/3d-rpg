using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;


public abstract class UserInterface : MonoBehaviour
{
	public static UserInterface Instance;

	public PlayerController player;

	public InventoryObject inventory;

	public Dictionary<GameObject, InventorySlot> slotOnInterface = new Dictionary<GameObject, InventorySlot>();

	private void Awake()
	{
		Instance = this;
	}
	void Start()
	{

		for(int i=0; i<inventory.GetSlots.Length; i++)
		{
			inventory.GetSlots[i].parent = this;
			inventory.GetSlots[i].OnAfterUpdate += OnSlotUpdate;

		}
		CreateSlots();

		AddEvent(gameObject, EventTriggerType.PointerEnter, delegate { OnEnterInterFace(gameObject); });
		AddEvent(gameObject, EventTriggerType.PointerExit, delegate { OnExitInterFace(gameObject); });

	}

	private void OnSlotUpdate(InventorySlot _slot)
	{
		if (_slot.item.Id >= 0)
		{
			_slot.slotDisplay.transform.GetChild(0).GetComponent<Image>().sprite = _slot.itemObject.uiDisplay;
			_slot.slotDisplay.transform.GetChild(0).GetComponent<Image>().color = new Color(1, 1, 1, 1);
			_slot.slotDisplay.GetComponentInChildren<TextMeshProUGUI>().text = _slot.amount == 1 ? "" : _slot.amount.ToString("n0");
		}
		else
		{
			_slot.slotDisplay.transform.GetChild(0).GetComponent<Image>().sprite = null;
			_slot.slotDisplay.transform.GetChild(0).GetComponent<Image>().color = new Color(1, 1, 1, 0.2F);
			_slot.slotDisplay.GetComponentInChildren<TextMeshProUGUI>().text = "";
		}
	}

	// Update is called once per frame
	//public virtual void Update()
	//{
	//	slotOnInterface.UpdateSlotDisPlay();
	//}



	protected void AddEvent(GameObject obj, EventTriggerType type, UnityAction<BaseEventData> action)
	{
		EventTrigger trigger = obj.GetComponent<EventTrigger>();
		var eventTrigger = new EventTrigger.Entry();
		eventTrigger.eventID = type;
		eventTrigger.callback.AddListener(action);
		trigger.triggers.Add(eventTrigger);
	}

	public abstract void CreateSlots();

	public void OnEnter(GameObject obj)
	{
		MouseData.slotHoverdOver = obj;
	}

	public void OnExit(GameObject obj)
	{
		MouseData.slotHoverdOver = null;
	}

	public void OnEnterInterFace(GameObject obj) 
	{
		MouseData.interfaceMouseIsOver = obj.GetComponent<UserInterface>();
	}

	public void OnExitInterFace(GameObject obj)
	{
		MouseData.interfaceMouseIsOver = null;
	}

	public void OnDragStart(GameObject obj)
	{
	
		player.isDrag = false;
		

		MouseData.tempItemBeginDragged= CreateTempItem(obj);
	}

	public GameObject CreateTempItem(GameObject obj)
	{
		GameObject tempItem = null;

		if (slotOnInterface[obj].item.Id >= 0)
		{
			tempItem = new GameObject();
			var rt = tempItem.AddComponent<RectTransform>();
			rt.sizeDelta = new Vector2(100, 100);
			tempItem.transform.SetParent(transform.parent);

			var image = tempItem.AddComponent<Image>();
			image.sprite = slotOnInterface[obj].itemObject.uiDisplay;
			image.raycastTarget = false;
		}

		return tempItem;
	}

	public void OnDragEnd(GameObject obj)
	{
		Destroy(MouseData.tempItemBeginDragged);
		
		if (MouseData.interfaceMouseIsOver == null)
		{
			slotOnInterface[obj].RemoveItem();
			return;
		}

		if (MouseData.slotHoverdOver)
		{
			InventorySlot mouseHoveSlotData = MouseData.interfaceMouseIsOver.slotOnInterface[MouseData.slotHoverdOver];
			inventory.SwapItems(slotOnInterface[obj], mouseHoveSlotData);
		}

		player.isDrag = true;

	}

	public void OnDrag(GameObject obj)
	{
		if (MouseData.tempItemBeginDragged != null)
		{
			MouseData.tempItemBeginDragged.GetComponent<RectTransform>().position = Input.mousePosition;
		}
	}


}

public static class MouseData
{
	public static UserInterface interfaceMouseIsOver;
	public static GameObject tempItemBeginDragged;
	public static GameObject slotHoverdOver;
}

public static class ExtensionMethods
{
	public static void UpdateSlotDisPlay(this Dictionary<GameObject, InventorySlot> _slotOnInterface)
	{
		foreach (KeyValuePair<GameObject, InventorySlot> _slot in _slotOnInterface)
		{

			if (_slot.Value.item.Id >= 0)
			{
				_slot.Key.transform.GetChild(0).GetComponent<Image>().sprite = _slot.Value.itemObject.uiDisplay;
				_slot.Key.transform.GetChild(0).GetComponent<Image>().color = new Color(1, 1, 1, 1);
				_slot.Key.GetComponentInChildren<TextMeshProUGUI>().text = _slot.Value.amount == 1 ? "" : _slot.Value.amount.ToString("n0");
			}
			else
			{
				_slot.Key.transform.GetChild(0).GetComponent<Image>().sprite = null;
				_slot.Key.transform.GetChild(0).GetComponent<Image>().color = new Color(1, 1, 1, 0.2F);
				_slot.Key.GetComponentInChildren<TextMeshProUGUI>().text = "";
			}
		}
	}
}