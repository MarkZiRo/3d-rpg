using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Default Object", menuName = "InventorySystem/Items/Equiptment")]
public class EquiptmentObject : ItemObject
{
	public void Awake()
	{
	//	type = ItemType.Weapon;
	}

	// Update is called once per frame
	void Update()
    {
        
    }
}
