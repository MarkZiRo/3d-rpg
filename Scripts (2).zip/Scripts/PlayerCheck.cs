using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

public class PlayerCheck : MonoBehaviour
{
    public bool isPlayer = false;
    public GameObject UI_Npc;
    public int NpcNumber;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(isPlayer)
        {
            if(Input.GetKeyDown(KeyCode.G))
            {
                switch(NpcNumber)
                {
                    case 0: 
                        Camera.main.transform.position = new Vector3(35, 4, 7);
                        break;
					case 1:
						Camera.main.transform.position = new Vector3(45, 4, 9);
						break;
				}
            
				UI_Npc.SetActive(true);
			}
        }
    }

	private void OnTriggerEnter(Collider other)
	{
		if(other.tag == "Player")
        {
            isPlayer = true;
            other.GetComponent<PlayerController>().isNpc = true;
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if(other.tag == "Player") 
        {
            isPlayer = false;
			other.GetComponent<PlayerController>().isNpc = false;
			UI_Npc.SetActive(false);
		}
	}

}
